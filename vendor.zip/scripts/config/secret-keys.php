
<?php

return [
    'googleClientID' => '116280855915-lmf7is25q9l2b5ch7qbcv31nbg237qd6.apps.googleusercontent.com',
    'googleClientSecret' => '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',
    'fbAppID' => '616255157021456',
    'fbAppSecret' => '14b55a7f4368ded39ffc2975e4b71fe9'
];

?>