<?php
     function secured_encryption($data){
        //$this->data = $data;
        $encryption_type = "AES-256-CBC"; // cipher algorithm
        $key = ['6d2d823df2e08c0d3cdf70f148998d49', 'fdb3a18c7b0a322fdb3a18c7b0a320d3'];
        //$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($encryption_type));
        $iv = "0104060809070508";
        $encrypted_data = openssl_encrypt($data, $encryption_type, $key[0], OPENSSL_RAW_DATA, $iv);
        $final_encryption = hash_hmac('SHA3-512', $encrypted_data, $key[1], true);
        $output = base64_encode($iv.$final_encryption.$encrypted_data);
        return $output;

        if($output):
            print_r("Encrypted data: $output<br/>");
        else:
            print("Error in encrypting data");
        endif;

        
    }

     function decrypt_data($data){
        $data = base64_decode($data);
        $encryption_type = "AES-256-CBC"; // cipher algorithm
        $key = ['6d2d823df2e08c0d3cdf70f148998d49', 'fdb3a18c7b0a322fdb3a18c7b0a320d3'];
        $ivlen = openssl_cipher_iv_length($encryption_type);
        $iv = substr($data, 0, $ivlen);
        //$iv = "p3c0p70t0S";
        $hmac = substr($data, $ivlen, $sha2len = 64);   
        $decrypt_data = substr($data, $ivlen + $sha2len);
        $final_decryption = openssl_decrypt($decrypt_data, $encryption_type, $key[0], OPENSSL_RAW_DATA, $iv);
        $calcmac = hash_hmac('SHA3-512', $decrypt_data, $key[1], true);

        if(hash_equals($hmac, $calcmac)):
            return $final_decryption;
        else:
            print("Error in decrypting data");
        endif;
    }
      
?>