<?php


class Sign_in_auth_Section extends DBconnection
{
    private $user_id, $username;
  

    public function User_Sign_in($func_mail, $func_password)
	{
		$this->u_mail = $func_mail;
		//$this->u_username = $func_username;
		$this->u_password = $func_password;
        $password_hash = md5($this->u_password);

        $sql = "SELECT id, username, email, password FROM users WHERE email='$this->u_mail'";
        $result = mysqli_query($this->connect(), $sql);
        $row = mysqli_fetch_assoc($result);

		if($result->num_rows > 0){

			$user_id = $row['id'];
			$user_name = $row['username'];
			$user_pwd = $row['password'];
			$user_email = $row['email'];


        //declare empty array to push array datas into
		//$responseData = array();
        
        if( $this->u_mail == $user_email  && $password_hash == $user_pwd){
            $_SESSION['id'] = $user_id;
			$_SESSION['username'] = $user_name;

			// prepare response body
			$responseBody = array(
				"message" => "authenticated",
                "auth_status" => 1,
				"username" => $_SESSION['username']
			);
        } 
        else {
            $responseBody = array(
				"message" => "Incorrect"
			);
        }
    }
    else {
        $responseBody = array(
            "message" => "Not_found"
        );
    }
		//$sql = "INSERT INTO users(email, username, password) VALUES('$this->u_mail', '$this->u_username', '$password_hash')";
		
            // send response data
			echo json_encode($responseBody);
	}
    

   

   

  
}
