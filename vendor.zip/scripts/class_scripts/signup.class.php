<?php


class Registration_Section extends DBconnection
{
    private $user_id, $username;
  

    public function signupUser($func_mail, $func_username, $func_password)
	{
		$this->u_mail = $func_mail;
		$this->u_username = $func_username;
		$this->u_password = $func_password;
        $password_hash = md5($this->u_password);

        $sql1 = "SELECT email FROM users WHERE email='$this->u_mail'";
        $result1 = mysqli_query($this->connect(), $sql1);

        //declare empty array to push array datas into
		//$responseData = array();
        
        if($result1->num_rows > 0)
		{
            $responseBody = array(
				"message" => "user_exists",
			);
        } 
        else {
        $sql = "INSERT INTO users(email, username, password) VALUES('$this->u_mail', '$this->u_username', '$password_hash')";
        $runSQL = mysqli_query($this->connect(), $sql);
            
	

		if (!$runSQL) {
			$responseBody = array(
				"message" => "error",
			);
			echo json_encode($responseBody);
		} 
        else {
			// use newly inserted username to get id for sessions
			$sql2 = "SELECT id, username FROM users WHERE username = '$func_username'";
			$runSQL2 = mysqli_query($this->connect(), $sql2);
			$row2 = mysqli_fetch_assoc($runSQL2);

			// STARTUP USER SESSIONS
			$_SESSION['id'] = $row2['id'];
			$_SESSION['username'] = $row2['username'];

			// prepare response body
			$responseBody = array(
				"message" => "authenticated",
				"username" => $_SESSION['username']
			);

			
		    }  
        }

		//$sql = "INSERT INTO users(email, username, password) VALUES('$this->u_mail', '$this->u_username', '$password_hash')";
		
            // send response data
			echo json_encode($responseBody);
	}
    

   

   

  
}
