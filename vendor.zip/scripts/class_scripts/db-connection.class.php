<?php

class DBconnection {
	private $server = "localhost";
	private $username = "root";
	private $password = "";
	private $dbname = "chatbot";
	

	public function __construct(){
		//Initialization Statements/Default Values Here...

	}

	public function connectpd(){
	
		$sql = "mysql:host=".$this->server.";dbname=".$this->dbname;
        $pdo = new PDO($sql, $this->username, $this->password);
		$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        if($pdo){
            try{
                return $pdo;
            }catch(IOException $e){
                $e->getMessage();
            }
        }else{
            return false;
        }
	}

	public function connect(){

		$connection = mysqli_connect($this->server, $this->username, $this->password, $this->dbname);
	

		if(!$connection){
			return "CONNECTION - ERROR ".mysqli_error($connection);
		}else {
			return $connection;
		}
	}

}

?>