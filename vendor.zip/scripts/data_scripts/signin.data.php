<?php
header("Content-Type: application/json");
// session_start();
session_set_cookie_params(300); // 300 seconds = 5 minutes

if (!isset($_SESSION)){
    session_start();
}

include '../class_scripts/db-connection.class.php';
include '../class_scripts/signin.class.php';


//$Sign_in_auth_Obj = new Sign_in_auth_Section();

if(isset($_POST['u_email'])) {
	$user_email = $_POST['u_email'];
	//$username = $_POST['u_name'];
	$user_password = $_POST['pwd'];

	$Sign_in_auth_Obj = new Sign_in_auth_Section();
	$Sign_in_auth_Obj-> User_Sign_in($user_email, $user_password);
}
    

/* if(isset($_POST['dataId']) & !empty($_POST['dataId'])) {

 $UserProfile_Obj->New_Item($_POST['dataId']);
} */

?>