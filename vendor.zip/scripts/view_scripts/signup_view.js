$(document).ready(function () {

    //console.log("This is the beginning");

    $('body').on('click','.register', function(event){
        event.preventDefault();
       //var username = document.getElementById('u_name');
       //console.log($("#u_name").val());

            var user_name = $("#u_name").val();
            var user_email = $("#u_email").val();
            var user_password = $("#u_pwd").val();
            var password = $("#u_passwd").val();

        if(user_name == "" || user_email == "" || password == "" || user_password == ""){
            $("#registration_warning").html("Please provide the information above");
            $("#registration_warning").show();
            setTimeout(function() {
                $("#registration_warning").hide();
              }, 5000);
        }
        else if(user_password != password){
            $("#registration_warning").html("Passwords don't match");
            $("#registration_warning").show();
            setTimeout(function() {
                $("#registration_warning").hide();
              }, 5000);
        }
        else {

            $.ajax({ 
                type: 'post', 
                url: 'scripts/data_scripts/signup.data.php',
                data: {u_name: user_name, u_email: user_email, pwd:password},
                dataType: 'json',
                    success: function (result) { 
                   //console.log(result);
                   //console.log(result.username);


                   if (result.username == user_name && result.message == 'authenticated'){
                    $("#registration_success").html("Sign Up successful, hold on while we redirect you to your stories");
                    $("#registration_success").show();
                    setTimeout(function() {
                        $("#registration_success").hide();
                        window.location.href = "chat.php";
                      }, 5000);
                   }

                   else if(result.message == 'user_exists')
                   {
                    $("#registration_warning").html(`Email already exists, please provide a new email or <a href="signin.php">sign in</a> with this email`);
                    $("#registration_warning").show();
                    setTimeout(function() {
                        $("#registration_warning").hide();
                      }, 5000);
                   }
                   
                   else{
                    $("#registration_warning").html("Sign up not successful");
                    $("#registration_warning").show();
                    setTimeout(function() {
                        $("#registration_warning").hide();
                      }, 5000);
                   }
                    
                  }
            });



           
        }
    });

    /* $.ajax({ 
        type: 'get', 
        url: 'scripts/data_scripts/signup.data.php',
        data: {},
        dataType: 'json',
            success: function (result) { 
           //console.log(result);
               
    
              
           
          
          
         
          }
    }); */
    
    });