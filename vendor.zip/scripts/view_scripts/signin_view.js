$(document).ready(function () {

   // console.log("This is the next");

    $('body').on('click','.user_auth', function(event){
        event.preventDefault();
        //console.log("This is the junction");
        var user_email = $("#u_name_mail").val();
        var user_password = $("#u_pwd").val();

        if(user_email == "" || user_password == ""){
            $("#auth_warning").html("Please provide the information above");
            $("#auth_warning").show();
            setTimeout(function() {
                $("#auth_warning").hide();
              }, 5000);
        }
       
        else {

            $.ajax({ 
                type: 'post', 
                url: 'scripts/data_scripts/signin.data.php',
                data: {u_email: user_email, pwd:user_password},
                dataType: 'json',
                    success: function (result) { 
                  // console.log(result);
                   //console.log(result.username);


                   if (result.message == 'authenticated' && result.auth_status == 1){
                    $("#auth_success").html("Sign in successful, hold on while we redirect you to your stories");
                    $("#auth_success").show();
                    setTimeout(function() {
                        $("#auth_success").hide();
                        window.location.href = "chat.php";
                      }, 5000);
                   }

                   else if(result.message == 'Incorrect' || result.message == 'Not_found')
                   {
                    $("#auth_warning").html(`Incorrect email or password`);
                    $("#auth_warning").show();
                    setTimeout(function() {
                        $("#auth_warning").hide();
                      }, 5000);
                   }
                   
                   
                  }
            });



           
        }

     });

    
    
    });