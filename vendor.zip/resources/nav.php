<style>
    .navbar{
    position: fixed;
    display: contents;
    background-color: transparent;
    }
</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container" style="margin-top: 10px; font-size: 15px;">
            <a class="navbar-brand" href="index.php">StoryBot</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="chat.php">Chat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="all_feedbacks.php">Feedbacks</a>
                    </li>
                    <li class="nav-item">
                       <!--  <form method="POST" action="logout.php">
                            <button type="submit" class="logout" id="logout_btn">Logout</button>
                        </form> -->

                        <!-- <a class="nav-link" href="logout.php">Logout</a> -->
                    </li>
                </ul>
            </div>
        </div>
    </nav>